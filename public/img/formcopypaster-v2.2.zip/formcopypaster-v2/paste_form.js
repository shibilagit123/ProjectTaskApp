//Paste form scripts

var storedLegal = chrome.storage.local.get('newStorage', function (items) {
    //console.log(items); 

    var obj = JSON.parse(items.newStorage);
    var key2;
    for (var key in obj) {
    if(key.length>12)
    {
	    key2 = key.substr(key.length - 12);
    }
    else
    {
    	key2 = key;
    }
      if (obj.hasOwnProperty(key)) {
      	$('form').inputValues(key2, obj[key]);
      }
    }
   
  });